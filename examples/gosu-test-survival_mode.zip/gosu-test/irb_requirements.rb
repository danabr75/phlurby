# irb -r ./irb_requirements.rb

require 'rubygems'
require 'gosu'
require 'gl'
require 'rmagick'
require_relative 'star.rb'
require_relative 'bullet.rb'
require_relative 'player.rb'
require_relative 'enemy_player.rb'